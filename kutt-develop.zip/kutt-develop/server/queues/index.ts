import { visit } from "./queues";

const queues = {
  visit
};

export default queues;
